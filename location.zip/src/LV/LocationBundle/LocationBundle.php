<?php

namespace LV\LocationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LocationBundle extends Bundle
{
}
