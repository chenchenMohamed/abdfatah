<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = [];
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_wdt']), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not__profiler_home;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', '_profiler_home'));
                    }

                    return $ret;
                }
                not__profiler_home:

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_search_results']), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler']), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_router']), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception']), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception_css']), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_twig_error_test']), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        elseif (0 === strpos($pathinfo, '/c')) {
            if (0 === strpos($pathinfo, '/cheque')) {
                // cheque_index
                if ('/cheque' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ChequeController::indexAction',  '_route' => 'cheque_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_cheque_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'cheque_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_cheque_index;
                    }

                    return $ret;
                }
                not_cheque_index:

                // cheque_show
                if (preg_match('#^/cheque/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'cheque_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ChequeController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_cheque_show;
                    }

                    return $ret;
                }
                not_cheque_show:

                // cheque_new
                if ('/cheque/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ChequeController::newAction',  '_route' => 'cheque_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_cheque_new;
                    }

                    return $ret;
                }
                not_cheque_new:

                // cheque_edit
                if (preg_match('#^/cheque/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'cheque_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ChequeController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_cheque_edit;
                    }

                    return $ret;
                }
                not_cheque_edit:

                // cheque_delete
                if (preg_match('#^/cheque/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'cheque_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ChequeController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_cheque_delete;
                    }

                    return $ret;
                }
                not_cheque_delete:

            }

            // chart
            if ('/chart' === $pathinfo) {
                return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::chartAction',  '_route' => 'chart',);
            }

            if (0 === strpos($pathinfo, '/csr')) {
                // csr_index
                if ('/csr' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\CSRController::indexAction',  '_route' => 'csr_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_csr_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'csr_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_csr_index;
                    }

                    return $ret;
                }
                not_csr_index:

                // csr_show
                if (preg_match('#^/csr/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'csr_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\CSRController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_csr_show;
                    }

                    return $ret;
                }
                not_csr_show:

                // csr_new
                if ('/csr/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\CSRController::newAction',  '_route' => 'csr_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_csr_new;
                    }

                    return $ret;
                }
                not_csr_new:

                // csr_edit
                if (preg_match('#^/csr/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'csr_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\CSRController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_csr_edit;
                    }

                    return $ret;
                }
                not_csr_edit:

                // csr_delete
                if (preg_match('#^/csr/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'csr_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\CSRController::deleteAction',));
                }

                // csr_new1
                if (0 === strpos($pathinfo, '/csr/new1') && preg_match('#^/csr/new1/(?P<time1>[^/]++)/(?P<time2>[^/]++)/(?P<result>[^/]++)/(?P<voiture>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'csr_new1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\CSRController::new1Action',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_csr_new1;
                    }

                    return $ret;
                }
                not_csr_new1:

            }

            elseif (0 === strpos($pathinfo, '/contrat')) {
                // contrat_index
                if ('/contrat' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ContratController::indexAction',  '_route' => 'contrat_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_contrat_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'contrat_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_contrat_index;
                    }

                    return $ret;
                }
                not_contrat_index:

                // contrat_show
                if (preg_match('#^/contrat/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'contrat_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ContratController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_contrat_show;
                    }

                    return $ret;
                }
                not_contrat_show:

                // contrat_new
                if ('/contrat/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ContratController::newAction',  '_route' => 'contrat_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_contrat_new;
                    }

                    return $ret;
                }
                not_contrat_new:

                // contrat_edit
                if (preg_match('#^/contrat/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'contrat_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ContratController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_contrat_edit;
                    }

                    return $ret;
                }
                not_contrat_edit:

                // contrat_delete
                if (preg_match('#^/contrat/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'contrat_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ContratController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_contrat_delete;
                    }

                    return $ret;
                }
                not_contrat_delete:

                // contrat_new1
                if (0 === strpos($pathinfo, '/contrat/new1') && preg_match('#^/contrat/new1/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'contrat_new1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ContratController::new1Action',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_contrat_new1;
                    }

                    return $ret;
                }
                not_contrat_new1:

            }

            elseif (0 === strpos($pathinfo, '/contact')) {
                // contact
                if ('/contact' === $pathinfo) {
                    return array (  '_controller' => 'LV\\UserBundle\\Controller\\DefaultController::contactAction',  '_route' => 'contact',);
                }

                // contactsuccess
                if ('/contactsuccess' === $pathinfo) {
                    return array (  '_controller' => 'LV\\UserBundle\\Controller\\DefaultController::contactSuccessAction',  '_route' => 'contactsuccess',);
                }

            }

            // credit
            if ('/credit' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::creditAction',  '_route' => 'credit',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_credit;
                }

                return $ret;
            }
            not_credit:

            if (0 === strpos($pathinfo, '/client')) {
                // client_index
                if ('/client' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ClientController::indexAction',  '_route' => 'client_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_client_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'client_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_client_index;
                    }

                    return $ret;
                }
                not_client_index:

                // client_show
                if (preg_match('#^/client/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'client_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ClientController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_client_show;
                    }

                    return $ret;
                }
                not_client_show:

                // client_new
                if ('/client/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ClientController::newAction',  '_route' => 'client_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_client_new;
                    }

                    return $ret;
                }
                not_client_new:

                // client_edit
                if (preg_match('#^/client/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'client_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ClientController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_client_edit;
                    }

                    return $ret;
                }
                not_client_edit:

                // client_edit2
                if (preg_match('#^/client/(?P<id>[^/]++)/edit2$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'client_edit2']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ClientController::edit2Action',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_client_edit2;
                    }

                    return $ret;
                }
                not_client_edit2:

                // client_delete
                if (preg_match('#^/client/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'client_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ClientController::deleteAction',));
                }

                // client_delete1
                if (preg_match('#^/client/(?P<id>[^/]++)/delete1$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'client_delete1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ClientController::delete1Action',));
                }

                // client_liste_noir
                if ('/client/listenoir' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ClientController::listeNoirAction',  '_route' => 'client_liste_noir',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_client_liste_noir;
                    }

                    return $ret;
                }
                not_client_liste_noir:

            }

        }

        elseif (0 === strpos($pathinfo, '/re')) {
            if (0 === strpos($pathinfo, '/rese')) {
                if (0 === strpos($pathinfo, '/reservation')) {
                    // reservation_index
                    if ('/reservation' === $trimmedPathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ReservationController::indexAction',  '_route' => 'reservation_index',);
                        if ('/' === substr($pathinfo, -1)) {
                            // no-op
                        } elseif ('GET' !== $canonicalMethod) {
                            goto not_reservation_index;
                        } else {
                            return array_replace($ret, $this->redirect($rawPathinfo.'/', 'reservation_index'));
                        }

                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_reservation_index;
                        }

                        return $ret;
                    }
                    not_reservation_index:

                    // reservation_show
                    if (preg_match('#^/reservation/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reservation_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ReservationController::showAction',));
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_reservation_show;
                        }

                        return $ret;
                    }
                    not_reservation_show:

                    // reservation_new
                    if ('/reservation/new' === $pathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ReservationController::newAction',  '_route' => 'reservation_new',);
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_reservation_new;
                        }

                        return $ret;
                    }
                    not_reservation_new:

                    // reservation_edit
                    if (preg_match('#^/reservation/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reservation_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ReservationController::editAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_reservation_edit;
                        }

                        return $ret;
                    }
                    not_reservation_edit:

                    // reservation_delete
                    if (preg_match('#^/reservation/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, ['_route' => 'reservation_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ReservationController::deleteAction',));
                    }

                    // reservation_search
                    if ('/reservation/search' === $pathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ReservationController::searchAction',  '_route' => 'reservation_search',);
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_reservation_search;
                        }

                        return $ret;
                    }
                    not_reservation_search:

                    // reservation_new1
                    if (0 === strpos($pathinfo, '/reservation/new1') && preg_match('#^/reservation/new1/(?P<time1>[^/]++)/(?P<time2>[^/]++)/(?P<result>[^/]++)/(?P<voiture>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reservation_new1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ReservationController::new1Action',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_reservation_new1;
                        }

                        return $ret;
                    }
                    not_reservation_new1:

                    // new_client
                    if ('/reservation/newclient' === $pathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ReservationController::newClientAction',  '_route' => 'new_client',);
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_new_client;
                        }

                        return $ret;
                    }
                    not_new_client:

                }

                elseif (0 === strpos($pathinfo, '/reserver')) {
                    // reserver
                    if ('/reserver' === $pathinfo) {
                        return array (  '_controller' => 'LV\\UserBundle\\Controller\\DefaultController::reserverAction',  '_route' => 'reserver',);
                    }

                    // reserver_result
                    if ('/reserverresult' === $pathinfo) {
                        return array (  '_controller' => 'LV\\UserBundle\\Controller\\DefaultController::reserverResultAction',  '_route' => 'reserver_result',);
                    }

                    // info
                    if ('/reserverinfo' === $pathinfo) {
                        return array (  '_controller' => 'LV\\UserBundle\\Controller\\DefaultController::infoAction',  'time1' => '',  'time2' => '',  'result' => '',  'voiture' => '',  '_route' => 'info',);
                    }

                    // reserversuccess
                    if ('/reserversuccess' === $pathinfo) {
                        return array (  '_controller' => 'LV\\UserBundle\\Controller\\DefaultController::reserverSuccessAction',  '_route' => 'reserversuccess',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/resetting')) {
                    // fos_user_resetting_request
                    if ('/resetting/request' === $pathinfo) {
                        $ret = array (  '_controller' => 'fos_user.resetting.controller:requestAction',  '_route' => 'fos_user_resetting_request',);
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_fos_user_resetting_request;
                        }

                        return $ret;
                    }
                    not_fos_user_resetting_request:

                    // fos_user_resetting_reset
                    if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_user_resetting_reset']), array (  '_controller' => 'fos_user.resetting.controller:resetAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_fos_user_resetting_reset;
                        }

                        return $ret;
                    }
                    not_fos_user_resetting_reset:

                    // fos_user_resetting_send_email
                    if ('/resetting/send-email' === $pathinfo) {
                        $ret = array (  '_controller' => 'fos_user.resetting.controller:sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                        if (!in_array($requestMethod, ['POST'])) {
                            $allow = array_merge($allow, ['POST']);
                            goto not_fos_user_resetting_send_email;
                        }

                        return $ret;
                    }
                    not_fos_user_resetting_send_email:

                    // fos_user_resetting_check_email
                    if ('/resetting/check-email' === $pathinfo) {
                        $ret = array (  '_controller' => 'fos_user.resetting.controller:checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_fos_user_resetting_check_email;
                        }

                        return $ret;
                    }
                    not_fos_user_resetting_check_email:

                }

            }

            elseif (0 === strpos($pathinfo, '/recette')) {
                if (0 === strpos($pathinfo, '/recettejour')) {
                    // recette_jour
                    if ('/recettejour' === $pathinfo) {
                        return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::recetteJourAction',  '_route' => 'recette_jour',);
                    }

                    // recette_jour1
                    if ('/recettejour1' === $pathinfo) {
                        return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::recetteJour1Action',  '_route' => 'recette_jour1',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/recettemois')) {
                    // recette_mois
                    if ('/recettemois' === $pathinfo) {
                        return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::recetteMoisAction',  '_route' => 'recette_mois',);
                    }

                    // recette_mois1
                    if ('/recettemois1' === $pathinfo) {
                        return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::recetteMois1Action',  '_route' => 'recette_mois1',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/recettean')) {
                    // recette_an
                    if ('/recettean' === $pathinfo) {
                        return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::recetteAnAction',  '_route' => 'recette_an',);
                    }

                    // recette_an1
                    if ('/recettean1' === $pathinfo) {
                        return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::recetteAn1Action',  '_route' => 'recette_an1',);
                    }

                }

            }

            elseif (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if ('/register' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'fos_user.registration.controller:registerAction',  '_route' => 'fos_user_registration_register',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_fos_user_registration_register;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'fos_user_registration_register'));
                    }

                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_fos_user_registration_register;
                    }

                    return $ret;
                }
                not_fos_user_registration_register:

                // fos_user_registration_check_email
                if ('/register/check-email' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.registration.controller:checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_user_registration_check_email;
                    }

                    return $ret;
                }
                not_fos_user_registration_check_email:

                if (0 === strpos($pathinfo, '/register/confirm')) {
                    // fos_user_registration_confirm
                    if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_user_registration_confirm']), array (  '_controller' => 'fos_user.registration.controller:confirmAction',));
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_fos_user_registration_confirm;
                        }

                        return $ret;
                    }
                    not_fos_user_registration_confirm:

                    // fos_user_registration_confirmed
                    if ('/register/confirmed' === $pathinfo) {
                        $ret = array (  '_controller' => 'fos_user.registration.controller:confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_fos_user_registration_confirmed;
                        }

                        return $ret;
                    }
                    not_fos_user_registration_confirmed:

                }

            }

            elseif (0 === strpos($pathinfo, '/retour')) {
                // retour_index
                if ('/retour' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\RetourController::indexAction',  '_route' => 'retour_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_retour_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'retour_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_retour_index;
                    }

                    return $ret;
                }
                not_retour_index:

                // retour_show
                if (preg_match('#^/retour/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'retour_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\RetourController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_retour_show;
                    }

                    return $ret;
                }
                not_retour_show:

                // retour_new
                if ('/retour/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\RetourController::newAction',  '_route' => 'retour_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_retour_new;
                    }

                    return $ret;
                }
                not_retour_new:

                // retour_edit
                if (preg_match('#^/retour/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'retour_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\RetourController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_retour_edit;
                    }

                    return $ret;
                }
                not_retour_edit:

                // retour_edit2
                if (preg_match('#^/retour/(?P<id>[^/]++)/edit2$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'retour_edit2']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\RetourController::edit2Action',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_retour_edit2;
                    }

                    return $ret;
                }
                not_retour_edit2:

                // retour_delete
                if (preg_match('#^/retour/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'retour_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\RetourController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_retour_delete;
                    }

                    return $ret;
                }
                not_retour_delete:

                // retour_new1
                if (0 === strpos($pathinfo, '/retour/new1') && preg_match('#^/retour/new1/(?P<id>[^/]++)/?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'retour_new1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\RetourController::new1Action',));
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_retour_new1;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'retour_new1'));
                    }

                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_retour_new1;
                    }

                    return $ret;
                }
                not_retour_new1:

                // retour_new2
                if (0 === strpos($pathinfo, '/retour/new2') && preg_match('#^/retour/new2/(?P<id>[^/]++)/?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'retour_new2']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\RetourController::new2Action',));
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_retour_new2;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'retour_new2'));
                    }

                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_retour_new2;
                    }

                    return $ret;
                }
                not_retour_new2:

            }

        }

        elseif (0 === strpos($pathinfo, '/rapport')) {
            // rapport
            if (preg_match('#^/rapport/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'rapport']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::rapportAction',));
            }

            // rapportParPeriode
            if (0 === strpos($pathinfo, '/rapportParPeriode') && preg_match('#^/rapportParPeriode/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'rapportParPeriode']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::reportByDateRangeAction',));
            }

        }

        elseif (0 === strpos($pathinfo, '/facture')) {
            // facture_index
            if ('/facture' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::indexAction',  '_route' => 'facture_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_facture_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'facture_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_facture_index;
                }

                return $ret;
            }
            not_facture_index:

            // facture_show
            if (preg_match('#^/facture/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_facture_show;
                }

                return $ret;
            }
            not_facture_show:

            if (0 === strpos($pathinfo, '/facture/new')) {
                // facture_new
                if (preg_match('#^/facture/new/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_new']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::newAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_facture_new;
                    }

                    return $ret;
                }
                not_facture_new:

                // facture_new1
                if (0 === strpos($pathinfo, '/facture/new1') && preg_match('#^/facture/new1/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_new1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::new1Action',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_facture_new1;
                    }

                    return $ret;
                }
                not_facture_new1:

            }

            // facture_edit
            if (preg_match('#^/facture/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_facture_edit;
                }

                return $ret;
            }
            not_facture_edit:

            // facture_delete
            if (preg_match('#^/facture/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::deleteAction',));
                if (!in_array($requestMethod, ['DELETE'])) {
                    $allow = array_merge($allow, ['DELETE']);
                    goto not_facture_delete;
                }

                return $ret;
            }
            not_facture_delete:

            // facture_pdf
            if (preg_match('#^/facture/(?P<id>[^/]++)/pdf$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_pdf']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::pdfAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_facture_pdf;
                }

                return $ret;
            }
            not_facture_pdf:

            // facture_new2
            if (0 === strpos($pathinfo, '/facture/new2') && preg_match('#^/facture/new2/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_new2']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::new2Action',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_facture_new2;
                }

                return $ret;
            }
            not_facture_new2:

            // facture_show2
            if (preg_match('#^/facture/(?P<id>[^/]++)/show2$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_show2']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::show2Action',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_facture_show2;
                }

                return $ret;
            }
            not_facture_show2:

            // facture_pdf2
            if (preg_match('#^/facture/(?P<id>[^/]++)/pdf2$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'facture_pdf2']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\FactureController::pdf2Action',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_facture_pdf2;
                }

                return $ret;
            }
            not_facture_pdf2:

        }

        elseif (0 === strpos($pathinfo, '/s')) {
            if (0 === strpos($pathinfo, '/soustraitance')) {
                // soustraitance_index
                if ('/soustraitance' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\SoustraitanceController::indexAction',  '_route' => 'soustraitance_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_soustraitance_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'soustraitance_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_soustraitance_index;
                    }

                    return $ret;
                }
                not_soustraitance_index:

                // soustraitance_show
                if (preg_match('#^/soustraitance/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'soustraitance_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\SoustraitanceController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_soustraitance_show;
                    }

                    return $ret;
                }
                not_soustraitance_show:

                // soustraitance_new
                if (0 === strpos($pathinfo, '/soustraitance/new') && preg_match('#^/soustraitance/new/(?P<voiture>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'soustraitance_new']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\SoustraitanceController::newAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_soustraitance_new;
                    }

                    return $ret;
                }
                not_soustraitance_new:

                // soustraitance_edit
                if (preg_match('#^/soustraitance/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'soustraitance_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\SoustraitanceController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_soustraitance_edit;
                    }

                    return $ret;
                }
                not_soustraitance_edit:

                // soustraitance_delete
                if (preg_match('#^/soustraitance/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'soustraitance_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\SoustraitanceController::deleteAction',));
                }

                // soustraitance_detail
                if (preg_match('#^/soustraitance/(?P<id>[^/]++)/detail$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'soustraitance_detail']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\SoustraitanceController::detailAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_soustraitance_detail;
                    }

                    return $ret;
                }
                not_soustraitance_detail:

                if (0 === strpos($pathinfo, '/soustraitance/search')) {
                    // soustraitance_search
                    if ('/soustraitance/search' === $pathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\SoustraitanceController::searchAction',  '_route' => 'soustraitance_search',);
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_soustraitance_search;
                        }

                        return $ret;
                    }
                    not_soustraitance_search:

                    // soustraitance_search_result
                    if ('/soustraitance/search/result' === $pathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\SoustraitanceController::search2Action',  '_route' => 'soustraitance_search_result',);
                        if (!in_array($requestMethod, ['POST'])) {
                            $allow = array_merge($allow, ['POST']);
                            goto not_soustraitance_search_result;
                        }

                        return $ret;
                    }
                    not_soustraitance_search_result:

                }

            }

            // scheduler_index
            if ('/scheduler' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\SchedulerController::indexAction',  '_route' => 'scheduler_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_scheduler_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'scheduler_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_scheduler_index;
                }

                return $ret;
            }
            not_scheduler_index:

            if (0 === strpos($pathinfo, '/scheduler/appointment-')) {
                // scheduler_create
                if ('/scheduler/appointment-create' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\SchedulerController::createAction',  '_route' => 'scheduler_create',);
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_scheduler_create;
                    }

                    return $ret;
                }
                not_scheduler_create:

                // scheduler_update
                if ('/scheduler/appointment-update' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\SchedulerController::updateAction',  '_route' => 'scheduler_update',);
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_scheduler_update;
                    }

                    return $ret;
                }
                not_scheduler_update:

                // scheduler_delete
                if ('/scheduler/appointment-delete' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\SchedulerController::deleteAction',  '_route' => 'scheduler_delete',);
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_scheduler_delete;
                    }

                    return $ret;
                }
                not_scheduler_delete:

            }

        }

        elseif (0 === strpos($pathinfo, '/p')) {
            if (0 === strpos($pathinfo, '/paiement')) {
                if (0 === strpos($pathinfo, '/paiementecheance')) {
                    // paiementecheance_index
                    if ('/paiementecheance' === $trimmedPathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementEcheanceController::indexAction',  '_route' => 'paiementecheance_index',);
                        if ('/' === substr($pathinfo, -1)) {
                            // no-op
                        } elseif ('GET' !== $canonicalMethod) {
                            goto not_paiementecheance_index;
                        } else {
                            return array_replace($ret, $this->redirect($rawPathinfo.'/', 'paiementecheance_index'));
                        }

                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_paiementecheance_index;
                        }

                        return $ret;
                    }
                    not_paiementecheance_index:

                    // paiementecheance_show
                    if (preg_match('#^/paiementecheance/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementecheance_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementEcheanceController::showAction',));
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_paiementecheance_show;
                        }

                        return $ret;
                    }
                    not_paiementecheance_show:

                    // paiementecheance_new
                    if (0 === strpos($pathinfo, '/paiementecheance/new') && preg_match('#^/paiementecheance/new/(?P<id>[^/]++)/(?P<date>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementecheance_new']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementEcheanceController::newAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_paiementecheance_new;
                        }

                        return $ret;
                    }
                    not_paiementecheance_new:

                    // paiementecheance_edit
                    if (preg_match('#^/paiementecheance/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementecheance_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementEcheanceController::editAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_paiementecheance_edit;
                        }

                        return $ret;
                    }
                    not_paiementecheance_edit:

                    // paiementecheance_annuler
                    if (preg_match('#^/paiementecheance/(?P<id>[^/]++)/(?P<date>[^/]++)/annuler$#sD', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementecheance_annuler']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementEcheanceController::annulerAction',));
                    }

                    // paiementecheance_delete
                    if (preg_match('#^/paiementecheance/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementecheance_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementEcheanceController::deleteAction',));
                        if (!in_array($requestMethod, ['DELETE'])) {
                            $allow = array_merge($allow, ['DELETE']);
                            goto not_paiementecheance_delete;
                        }

                        return $ret;
                    }
                    not_paiementecheance_delete:

                }

                elseif (0 === strpos($pathinfo, '/paiementsoustraitance')) {
                    // paiementsoustraitance_index
                    if ('/paiementsoustraitance' === $trimmedPathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementSoustraitanceController::indexAction',  '_route' => 'paiementsoustraitance_index',);
                        if ('/' === substr($pathinfo, -1)) {
                            // no-op
                        } elseif ('GET' !== $canonicalMethod) {
                            goto not_paiementsoustraitance_index;
                        } else {
                            return array_replace($ret, $this->redirect($rawPathinfo.'/', 'paiementsoustraitance_index'));
                        }

                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_paiementsoustraitance_index;
                        }

                        return $ret;
                    }
                    not_paiementsoustraitance_index:

                    // paiementsoustraitance_show
                    if (preg_match('#^/paiementsoustraitance/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementsoustraitance_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementSoustraitanceController::showAction',));
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_paiementsoustraitance_show;
                        }

                        return $ret;
                    }
                    not_paiementsoustraitance_show:

                    // paiementsoustraitance_new
                    if (0 === strpos($pathinfo, '/paiementsoustraitance/new') && preg_match('#^/paiementsoustraitance/new/(?P<id>[^/]++)/(?P<date>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementsoustraitance_new']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementSoustraitanceController::newAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_paiementsoustraitance_new;
                        }

                        return $ret;
                    }
                    not_paiementsoustraitance_new:

                    // paiementsoustraitance_edit
                    if (preg_match('#^/paiementsoustraitance/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementsoustraitance_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementSoustraitanceController::editAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_paiementsoustraitance_edit;
                        }

                        return $ret;
                    }
                    not_paiementsoustraitance_edit:

                    // paiementsoustraitance_annuler
                    if (preg_match('#^/paiementsoustraitance/(?P<id>[^/]++)/(?P<date>[^/]++)/annuler$#sD', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementsoustraitance_annuler']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementSoustraitanceController::annulerAction',));
                    }

                    // paiementsoustraitance_delete
                    if (preg_match('#^/paiementsoustraitance/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiementsoustraitance_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementSoustraitanceController::deleteAction',));
                        if (!in_array($requestMethod, ['DELETE'])) {
                            $allow = array_merge($allow, ['DELETE']);
                            goto not_paiementsoustraitance_delete;
                        }

                        return $ret;
                    }
                    not_paiementsoustraitance_delete:

                }

                // paiement_index
                if ('/paiement' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementController::indexAction',  '_route' => 'paiement_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_paiement_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'paiement_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_paiement_index;
                    }

                    return $ret;
                }
                not_paiement_index:

                // paiement_show
                if (preg_match('#^/paiement/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiement_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_paiement_show;
                    }

                    return $ret;
                }
                not_paiement_show:

                if (0 === strpos($pathinfo, '/paiement/new')) {
                    // paiement_new
                    if (preg_match('#^/paiement/new/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiement_new']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementController::newAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_paiement_new;
                        }

                        return $ret;
                    }
                    not_paiement_new:

                    // paiement_new2
                    if (0 === strpos($pathinfo, '/paiement/new2') && preg_match('#^/paiement/new2/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiement_new2']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementController::new2Action',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_paiement_new2;
                        }

                        return $ret;
                    }
                    not_paiement_new2:

                }

                // paiement_edit
                if (preg_match('#^/paiement/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiement_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_paiement_edit;
                    }

                    return $ret;
                }
                not_paiement_edit:

                // paiement_edit1
                if (preg_match('#^/paiement/(?P<id>[^/]++)/edit1$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiement_edit1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementController::edit1Action',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_paiement_edit1;
                    }

                    return $ret;
                }
                not_paiement_edit1:

                // paiement_edit2
                if (preg_match('#^/paiement/(?P<id>[^/]++)/edit2$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiement_edit2']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementController::edit2Action',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_paiement_edit2;
                    }

                    return $ret;
                }
                not_paiement_edit2:

                // paiement_delete
                if (preg_match('#^/paiement/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'paiement_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\PaiementController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_paiement_delete;
                    }

                    return $ret;
                }
                not_paiement_delete:

            }

            // print2
            if ('/print2' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::print2Action',  '_route' => 'print2',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_print2;
                }

                return $ret;
            }
            not_print2:

            if (0 === strpos($pathinfo, '/profile')) {
                // fos_user_profile_show
                if ('/profile' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'fos_user.profile.controller:showAction',  '_route' => 'fos_user_profile_show',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_fos_user_profile_show;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'fos_user_profile_show'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_user_profile_show;
                    }

                    return $ret;
                }
                not_fos_user_profile_show:

                // fos_user_profile_edit
                if ('/profile/edit' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.profile.controller:editAction',  '_route' => 'fos_user_profile_edit',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_fos_user_profile_edit;
                    }

                    return $ret;
                }
                not_fos_user_profile_edit:

                // fos_user_change_password
                if ('/profile/change-password' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.change_password.controller:changePasswordAction',  '_route' => 'fos_user_change_password',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_fos_user_change_password;
                    }

                    return $ret;
                }
                not_fos_user_change_password:

            }

        }

        elseif (0 === strpos($pathinfo, '/depenses')) {
            // depenses_index
            if ('/depenses' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DepensesController::indexAction',  '_route' => 'depenses_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_depenses_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'depenses_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_depenses_index;
                }

                return $ret;
            }
            not_depenses_index:

            // depenses_show
            if (preg_match('#^/depenses/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'depenses_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\DepensesController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_depenses_show;
                }

                return $ret;
            }
            not_depenses_show:

            // depenses_new
            if ('/depenses/new' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DepensesController::newAction',  '_route' => 'depenses_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_depenses_new;
                }

                return $ret;
            }
            not_depenses_new:

            // depenses_edit
            if (preg_match('#^/depenses/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'depenses_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\DepensesController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_depenses_edit;
                }

                return $ret;
            }
            not_depenses_edit:

            // depenses_delete
            if (preg_match('#^/depenses/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'depenses_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\DepensesController::deleteAction',));
            }

        }

        elseif (0 === strpos($pathinfo, '/disponibilite')) {
            // disponibilite_index
            if ('/disponibilite' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DisponibiliteController::indexAction',  '_route' => 'disponibilite_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_disponibilite_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'disponibilite_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_disponibilite_index;
                }

                return $ret;
            }
            not_disponibilite_index:

            // disponibilite_show
            if (preg_match('#^/disponibilite/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'disponibilite_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\DisponibiliteController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_disponibilite_show;
                }

                return $ret;
            }
            not_disponibilite_show:

            // disponibilite_new
            if ('/disponibilite/new' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DisponibiliteController::newAction',  '_route' => 'disponibilite_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_disponibilite_new;
                }

                return $ret;
            }
            not_disponibilite_new:

            // disponibilite_edit
            if (preg_match('#^/disponibilite/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'disponibilite_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\DisponibiliteController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_disponibilite_edit;
                }

                return $ret;
            }
            not_disponibilite_edit:

            // disponibilite_delete
            if (preg_match('#^/disponibilite/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'disponibilite_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\DisponibiliteController::deleteAction',));
                if (!in_array($requestMethod, ['DELETE'])) {
                    $allow = array_merge($allow, ['DELETE']);
                    goto not_disponibilite_delete;
                }

                return $ret;
            }
            not_disponibilite_delete:

            if (0 === strpos($pathinfo, '/disponibilite/search')) {
                // disponibilite_search
                if ('/disponibilite/search' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DisponibiliteController::searchAction',  '_route' => 'disponibilite_search',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_disponibilite_search;
                    }

                    return $ret;
                }
                not_disponibilite_search:

                // disponibilite_search_result
                if ('/disponibilite/search/result' === $pathinfo) {
                    return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DisponibiliteController::search2Action',  '_route' => 'disponibilite_search_result',);
                }

            }

        }

        elseif (0 === strpos($pathinfo, '/typedepenses')) {
            // typedepenses_index
            if ('/typedepenses' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\TypeDepensesController::indexAction',  '_route' => 'typedepenses_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_typedepenses_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'typedepenses_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_typedepenses_index;
                }

                return $ret;
            }
            not_typedepenses_index:

            // typedepenses_show
            if (preg_match('#^/typedepenses/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'typedepenses_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\TypeDepensesController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_typedepenses_show;
                }

                return $ret;
            }
            not_typedepenses_show:

            // typedepenses_new
            if ('/typedepenses/new' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\TypeDepensesController::newAction',  '_route' => 'typedepenses_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_typedepenses_new;
                }

                return $ret;
            }
            not_typedepenses_new:

            // typedepenses_edit
            if (preg_match('#^/typedepenses/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'typedepenses_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\TypeDepensesController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_typedepenses_edit;
                }

                return $ret;
            }
            not_typedepenses_edit:

            // typedepenses_delete
            if (preg_match('#^/typedepenses/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'typedepenses_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\TypeDepensesController::deleteAction',));
            }

        }

        elseif (0 === strpos($pathinfo, '/a')) {
            if (0 === strpos($pathinfo, '/agence')) {
                // agence_index
                if ('/agence' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\AgenceController::indexAction',  '_route' => 'agence_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_agence_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'agence_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_agence_index;
                    }

                    return $ret;
                }
                not_agence_index:

                // agence_show
                if (preg_match('#^/agence/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'agence_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\AgenceController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_agence_show;
                    }

                    return $ret;
                }
                not_agence_show:

                // agence_new
                if ('/agence/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\AgenceController::newAction',  '_route' => 'agence_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_agence_new;
                    }

                    return $ret;
                }
                not_agence_new:

                // agence_edit
                if (preg_match('#^/agence/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'agence_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\AgenceController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_agence_edit;
                    }

                    return $ret;
                }
                not_agence_edit:

                // agence_delete
                if (preg_match('#^/agence/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'agence_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\AgenceController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_agence_delete;
                    }

                    return $ret;
                }
                not_agence_delete:

            }

            elseif (0 === strpos($pathinfo, '/assurance')) {
                // assurance_index
                if ('/assurance' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\AssuranceController::indexAction',  '_route' => 'assurance_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_assurance_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'assurance_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_assurance_index;
                    }

                    return $ret;
                }
                not_assurance_index:

                // assurance_show
                if (preg_match('#^/assurance/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'assurance_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\AssuranceController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_assurance_show;
                    }

                    return $ret;
                }
                not_assurance_show:

                if (0 === strpos($pathinfo, '/assurance/new')) {
                    // assurance_new
                    if ('/assurance/new' === $pathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\AssuranceController::newAction',  '_route' => 'assurance_new',);
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_assurance_new;
                        }

                        return $ret;
                    }
                    not_assurance_new:

                    // assurance_new1
                    if (0 === strpos($pathinfo, '/assurance/new1') && preg_match('#^/assurance/new1/(?P<num>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'assurance_new1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\AssuranceController::new1Action',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_assurance_new1;
                        }

                        return $ret;
                    }
                    not_assurance_new1:

                }

                // assurance_edit
                if (preg_match('#^/assurance/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'assurance_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\AssuranceController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_assurance_edit;
                    }

                    return $ret;
                }
                not_assurance_edit:

                // assurance_delete
                if (preg_match('#^/assurance/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'assurance_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\AssuranceController::deleteAction',));
                }

            }

            elseif (0 === strpos($pathinfo, '/accueil')) {
                // accueil
                if ('/accueil' === $pathinfo) {
                    return array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::indexAction',  '_route' => 'accueil',);
                }

                // accueilclient
                if ('/accueilclient' === $pathinfo) {
                    return array (  '_controller' => 'LV\\UserBundle\\Controller\\DefaultController::accueilClientAction',  '_route' => 'accueilclient',);
                }

                // location_default
                if ('/accueil' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::indexAction',  '_route' => 'location_default',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_location_default;
                    }

                    return $ret;
                }
                not_location_default:

            }

        }

        elseif (0 === strpos($pathinfo, '/v')) {
            if (0 === strpos($pathinfo, '/visite')) {
                // visite_index
                if ('/visite' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\VisiteController::indexAction',  '_route' => 'visite_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_visite_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'visite_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_visite_index;
                    }

                    return $ret;
                }
                not_visite_index:

                // visite_show
                if (preg_match('#^/visite/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'visite_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VisiteController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_visite_show;
                    }

                    return $ret;
                }
                not_visite_show:

                if (0 === strpos($pathinfo, '/visite/new')) {
                    // visite_new
                    if (preg_match('#^/visite/new/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'visite_new']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VisiteController::newAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_visite_new;
                        }

                        return $ret;
                    }
                    not_visite_new:

                    // visite_new1
                    if (0 === strpos($pathinfo, '/visite/new1') && preg_match('#^/visite/new1/(?P<voiture>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'visite_new1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VisiteController::new1Action',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_visite_new1;
                        }

                        return $ret;
                    }
                    not_visite_new1:

                    // visite_new2
                    if ('/visite/new2/%s' === $pathinfo) {
                        $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\VisiteController::new2Action',  '_route' => 'visite_new2',);
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_visite_new2;
                        }

                        return $ret;
                    }
                    not_visite_new2:

                }

                // visite_edit
                if (preg_match('#^/visite/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'visite_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VisiteController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_visite_edit;
                    }

                    return $ret;
                }
                not_visite_edit:

                // visite_delete
                if (preg_match('#^/visite/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'visite_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VisiteController::deleteAction',));
                }

            }

            elseif (0 === strpos($pathinfo, '/vidange')) {
                // vidange_index
                if ('/vidange' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\VidangeController::indexAction',  '_route' => 'vidange_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_vidange_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'vidange_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_vidange_index;
                    }

                    return $ret;
                }
                not_vidange_index:

                // vidange_show
                if (preg_match('#^/vidange/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'vidange_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VidangeController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_vidange_show;
                    }

                    return $ret;
                }
                not_vidange_show:

                if (0 === strpos($pathinfo, '/vidange/new')) {
                    // vidange_new
                    if (preg_match('#^/vidange/new/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'vidange_new']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VidangeController::newAction',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_vidange_new;
                        }

                        return $ret;
                    }
                    not_vidange_new:

                    // vidange_new1
                    if (0 === strpos($pathinfo, '/vidange/new1') && preg_match('#^/vidange/new1/(?P<voiture>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'vidange_new1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VidangeController::new1Action',));
                        if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                            $allow = array_merge($allow, ['GET', 'POST']);
                            goto not_vidange_new1;
                        }

                        return $ret;
                    }
                    not_vidange_new1:

                }

                // vidange_edit
                if (preg_match('#^/vidange/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'vidange_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VidangeController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_vidange_edit;
                    }

                    return $ret;
                }
                not_vidange_edit:

                // vidange_delete
                if (preg_match('#^/vidange/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'vidange_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VidangeController::deleteAction',));
                }

            }

            elseif (0 === strpos($pathinfo, '/voiture')) {
                // voiture_index
                if ('/voiture' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\VoitureController::indexAction',  '_route' => 'voiture_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_voiture_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'voiture_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_voiture_index;
                    }

                    return $ret;
                }
                not_voiture_index:

                // voiture_index2
                if ('/voiture/voituressoustraitance' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\VoitureController::index2Action',  '_route' => 'voiture_index2',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_voiture_index2;
                    }

                    return $ret;
                }
                not_voiture_index2:

                // voiture_show
                if (preg_match('#^/voiture/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'voiture_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VoitureController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_voiture_show;
                    }

                    return $ret;
                }
                not_voiture_show:

                // voiture_new
                if ('/voiture/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\VoitureController::newAction',  '_route' => 'voiture_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_voiture_new;
                    }

                    return $ret;
                }
                not_voiture_new:

                // voiture_edit
                if (preg_match('#^/voiture/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'voiture_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VoitureController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_voiture_edit;
                    }

                    return $ret;
                }
                not_voiture_edit:

                // voiture_delete
                if (preg_match('#^/voiture/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'voiture_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VoitureController::deleteAction',));
                }

                // voiture_delete1
                if (preg_match('#^/voiture/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'voiture_delete1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\VoitureController::delete1Action',));
                }

                // marque_list_modeles
                if ('/voiture/get-modeles-from-marque' === $pathinfo) {
                    $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\VoitureController::listModelesOfMarqueAction',  '_route' => 'marque_list_modeles',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_marque_list_modeles;
                    }

                    return $ret;
                }
                not_marque_list_modeles:

                // voitures
                if ('/voitures' === $pathinfo) {
                    return array (  '_controller' => 'LV\\UserBundle\\Controller\\DefaultController::voituresAction',  '_route' => 'voitures',);
                }

            }

        }

        elseif (0 === strpos($pathinfo, '/echeance')) {
            // echeance_index
            if ('/echeance' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\EcheanceController::indexAction',  '_route' => 'echeance_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_echeance_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'echeance_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_echeance_index;
                }

                return $ret;
            }
            not_echeance_index:

            // echeance_show
            if (preg_match('#^/echeance/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'echeance_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\EcheanceController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_echeance_show;
                }

                return $ret;
            }
            not_echeance_show:

            // echeance_new
            if ('/echeance/new' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\EcheanceController::newAction',  '_route' => 'echeance_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_echeance_new;
                }

                return $ret;
            }
            not_echeance_new:

            // echeance_edit
            if (preg_match('#^/echeance/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'echeance_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\EcheanceController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_echeance_edit;
                }

                return $ret;
            }
            not_echeance_edit:

            // echeance_delete
            if (preg_match('#^/echeance/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'echeance_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\EcheanceController::deleteAction',));
            }

            // echeance_detail
            if (preg_match('#^/echeance/(?P<id>[^/]++)/detail$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'echeance_detail']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\EcheanceController::detailAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_echeance_detail;
                }

                return $ret;
            }
            not_echeance_detail:

        }

        elseif (0 === strpos($pathinfo, '/entretien')) {
            // entretien
            if (preg_match('#^/entretien/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'entretien']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\EntretienController::indexAction',));
            }

            // entretien1
            if (0 === strpos($pathinfo, '/entretien/index1') && preg_match('#^/entretien/index1/(?P<voiture>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'entretien1']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\EntretienController::index1Action',));
            }

        }

        // location_homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\DefaultController::indexAction',  '_route' => 'location_homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_location_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'location_homepage'));
            }

            if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                $allow = array_merge($allow, ['GET', 'POST']);
                goto not_location_homepage;
            }

            return $ret;
        }
        not_location_homepage:

        if (0 === strpos($pathinfo, '/user')) {
            // user_index
            if ('/user' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\UserBundle\\Controller\\UserController::indexAction',  '_route' => 'user_index',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_user_index;
                }

                return $ret;
            }
            not_user_index:

            // user_edit
            if (preg_match('#^/user/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'user_edit']), array (  '_controller' => 'LV\\UserBundle\\Controller\\UserController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_user_edit;
                }

                return $ret;
            }
            not_user_edit:

            // user_show
            if (preg_match('#^/user/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'user_show']), array (  '_controller' => 'LV\\UserBundle\\Controller\\UserController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_user_show;
                }

                return $ret;
            }
            not_user_show:

            // user_delete
            if (preg_match('#^/user/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'user_delete']), array (  '_controller' => 'LV\\UserBundle\\Controller\\UserController::deleteAction',));
            }

        }

        elseif (0 === strpos($pathinfo, '/login')) {
            // fos_user_security_login
            if ('/login' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.security.controller:loginAction',  '_route' => 'fos_user_security_login',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_fos_user_security_login;
                }

                return $ret;
            }
            not_fos_user_security_login:

            // fos_user_security_check
            if ('/login_check' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.security.controller:checkAction',  '_route' => 'fos_user_security_check',);
                if (!in_array($requestMethod, ['POST'])) {
                    $allow = array_merge($allow, ['POST']);
                    goto not_fos_user_security_check;
                }

                return $ret;
            }
            not_fos_user_security_check:

        }

        // fos_user_security_logout
        if ('/logout' === $pathinfo) {
            $ret = array (  '_controller' => 'fos_user.security.controller:logoutAction',  '_route' => 'fos_user_security_logout',);
            if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                $allow = array_merge($allow, ['GET', 'POST']);
                goto not_fos_user_security_logout;
            }

            return $ret;
        }
        not_fos_user_security_logout:

        if (0 === strpos($pathinfo, '/marque')) {
            // marque_index
            if ('/marque' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\MarqueController::indexAction',  '_route' => 'marque_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_marque_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'marque_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_marque_index;
                }

                return $ret;
            }
            not_marque_index:

            // marque_show
            if (preg_match('#^/marque/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'marque_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\MarqueController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_marque_show;
                }

                return $ret;
            }
            not_marque_show:

            // marque_new
            if ('/marque/new' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\MarqueController::newAction',  '_route' => 'marque_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_marque_new;
                }

                return $ret;
            }
            not_marque_new:

            // marque_edit
            if (preg_match('#^/marque/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'marque_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\MarqueController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_marque_edit;
                }

                return $ret;
            }
            not_marque_edit:

            // marque_delete
            if (preg_match('#^/marque/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'marque_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\MarqueController::deleteAction',));
                if (!in_array($requestMethod, ['DELETE'])) {
                    $allow = array_merge($allow, ['DELETE']);
                    goto not_marque_delete;
                }

                return $ret;
            }
            not_marque_delete:

        }

        elseif (0 === strpos($pathinfo, '/modele')) {
            // modele_index
            if ('/modele' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ModeleController::indexAction',  '_route' => 'modele_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_modele_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'modele_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_modele_index;
                }

                return $ret;
            }
            not_modele_index:

            // modele_show
            if (preg_match('#^/modele/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'modele_show']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ModeleController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_modele_show;
                }

                return $ret;
            }
            not_modele_show:

            // modele_new
            if ('/modele/new' === $pathinfo) {
                $ret = array (  '_controller' => 'LV\\LocationBundle\\Controller\\ModeleController::newAction',  '_route' => 'modele_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_modele_new;
                }

                return $ret;
            }
            not_modele_new:

            // modele_edit
            if (preg_match('#^/modele/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'modele_edit']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ModeleController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_modele_edit;
                }

                return $ret;
            }
            not_modele_edit:

            // modele_delete
            if (preg_match('#^/modele/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'modele_delete']), array (  '_controller' => 'LV\\LocationBundle\\Controller\\ModeleController::deleteAction',));
                if (!in_array($requestMethod, ['DELETE'])) {
                    $allow = array_merge($allow, ['DELETE']);
                    goto not_modele_delete;
                }

                return $ret;
            }
            not_modele_delete:

        }

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
